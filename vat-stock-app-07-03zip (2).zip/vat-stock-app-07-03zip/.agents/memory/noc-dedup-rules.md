---
name: NOC purchase dedup rules
description: How NOC portal purchases are deduplicated and which fields are stored vs fabricated.
---

## Dedup key (buildNocDedupKey)
Format: `NOC-{YYYYMMDD}-{HSD|MS}-{qty_rounded}-R{rate*100_rounded}`

**Why:** Same-day deliveries of same product at same quantity and rate are duplicates from the portal. txSummary (transaction summary column) is NOT used — it can differ for genuinely identical deliveries depending on portal page/session.

**How to apply:** Any change to the dedup key format must also consider: (a) existing stable IDs in Firestore will shift for all records, and (b) the in-session Set dedup in `scrapeNOCHTMLTable` uses `purchase.id` (not `billNo`).

## billNo field
Store `txSummary.trim()` if the portal provides it, otherwise store `""`.

**Why:** User explicitly said "do not add bill no automatically if NOC website doesn't provide it." The old code stored the internal dedup key as billNo — that was fabrication.

## total field
Always compute `total = Math.round((taxable + vat) * 100) / 100`.

**Why:** NOC AR Invoice format: taxable + VAT = total (e.g. 2,224,744.56 + 289,216.79 = 2,513,961.35). Raw column 7 from the portal is unreliable/absent. Computing from known values is exact.

## Sync Now date range
When Sync Now is clicked without manual date overrides, auto-compute the current Nepali fiscal year AD range:
- `dateFrom` = `bsToAdStr(bsYear, 4, 1)` (Shrawan 1 of BS year)
- `dateTo` = `bsToAdStr(bsYear+1, 3, 32)` (Ashadh end of next BS year; falls back to day 31)
- Manual `syncDateFrom`/`syncDateTo` override the auto range if set.

## Ledger sync on Sync Now
After portal sync completes successfully, `triggerLedgerSync(config, dateFrom, dateTo)` is called automatically for the same date range. This updates `ledgerReport` state so Ledger Reconciliation tab is always current after each sync.
