---
name: Portal sync partial independence
description: NOC and SPAS portal syncs are independent; partial data must still be imported
---

## Rule
NOC (purchases) and SPAS (sales) portal syncs must run in separate try/catch blocks and never block each other.

**Why:** The SPAS portal (spas.taradigitalsolution.com.np:1176) is unreachable from Replit's container (connection timeout). NOC portal (eservice.nepaloil.org.np) works fine. If both run in the same try/catch, the SPAS timeout kills the NOC result.

**How to apply:**
- In server.ts: two separate try/catch blocks; finalize with `status = "success"` + `partialError` if only one failed.
- In App.tsx `handleImportSyncResult`: always call this if `status === "success" || hasPartialData`; check `result.purchases?.length > 0 || result.sales?.length > 0`.
- The `/api/portal-sync/:jobId/result` endpoint must return the result even when status is "error" (partial data case).
- Validation in `handleTriggerPortalSync` only requires NOC credentials (`nocUsername`, `nocPassword`); SPAS URL is optional.
