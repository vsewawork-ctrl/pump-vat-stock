---
name: Reconciliation two-pass matching
description: The ledger reconciliation had a same-date duplicate bug; fixed with two-pass matching in buildReconciliationReport.
---

## The rule
`buildReconciliationReport` in `server.ts` must use two-pass matching to avoid same-date entries consuming each other silently.

- **Pass 1:** Loop all ledger entries → for each, find first purchase on same date with `Math.abs(purchaseAmount - ledgerAmount) < 1`. Lock both as matched.
- **Pass 2:** Loop only unmatched ledger entries → for each, find first unmatched purchase on same date with diff < Rs 1000 → record as `amountMismatch`.

**Why:** Single-pass matching would pair the first same-date ledger entry with the first same-date purchase regardless of amounts, leaving subsequent same-date entries orphaned. The two-pass approach ensures exact matches are claimed first, preventing them from being stolen by lower-priority mismatch pairs.

**How to apply:** Any change to the matching logic in `buildReconciliationReport` must preserve this two-pass ordering. Never merge into a single loop.
