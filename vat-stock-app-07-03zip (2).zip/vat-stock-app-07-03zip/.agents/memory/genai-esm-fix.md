---
name: genai ESM truncation fix
description: @google/genai dist/node/index.mjs silently truncates during npm install in this environment; tsx and Node.js both fail to parse the incomplete file.
---

## The problem
`node_modules/@google/genai/dist/node/index.mjs` (the ESM node build) silently truncates at ~285 KB mid-file during npm install in this Replit environment. This causes:
- tsx: `Parse error … index.mjs:1:1` (lexer hits end-of-file unexpectedly)
- Node.js direct: `SyntaxError: Invalid or unexpected token` at the truncation point

**Why:** The CJS build (`dist/index.cjs`, ~973 KB) installs correctly. Only the ESM node build truncates. Likely a disk-write or network-interruption issue during `npm install`.

## The fix
Overwrite the broken ESM file with a thin shim that re-exports from the working CJS build:

```js
import { createRequire } from 'module';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const require = createRequire(import.meta.url);
const _cjs = require(join(__dirname, '../index.cjs'));

export const { GoogleGenAI, Type, ApiError, ... } = _cjs;
export default _cjs;
```

**How to apply:** Run this after any npm install that installs/updates `@google/genai`, or check `wc -l node_modules/@google/genai/dist/node/index.mjs` — a complete file should be ~10 000+ lines; if it's ~7 451 lines it is truncated.

The workflow command `PORT=5000 ./node_modules/.bin/tsx server.ts` works correctly once this shim is in place.
