---
name: Portal scraper node-fetch fix
description: Why native fetch fails in the tsx/Express server and node-fetch must be used instead
---

## Rule
Always use `node-fetch` (not native `fetch`) in `src/lib/scraper.ts` for HTTP requests.

**Why:** Node.js 20 native fetch (undici) throws "fetch failed" when used inside the tsx/Express dev server for multi-step login flows (GET login page → POST with redirect:manual → GET report). The same native fetch works fine in standalone node scripts. Switching to `import nodeFetch from "node-fetch"` (v3.3.2, ESM) fixes the issue.

**How to apply:** Use `nodeFetch()` in `httpGet` and `httpPost` functions. For the manual redirect POST, use `redirect: ("manual" as any)`. Use `AbortController` + `setTimeout` for timeout (not `AbortSignal.timeout()` which may not be supported by node-fetch). node-fetch Headers has `getAll("set-cookie")` instead of native fetch's `getSetCookie()` — the CookieJar handles both.
